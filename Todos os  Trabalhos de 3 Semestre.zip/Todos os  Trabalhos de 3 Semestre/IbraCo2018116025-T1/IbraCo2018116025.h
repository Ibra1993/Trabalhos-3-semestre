
int q1(char *data);
int q2(char *datainicial, char *datafinal, int *qtdDias, int *qtdMeses, int *qtdAnos);
int q3(char str[250], char letra, int Case_Sensitive);
int q4(char *strTexto, char *strBusca, int posicoes[30]);
int q5(int Numero_de_Entrada );
int q6(int numerobase, int numerobusca);
