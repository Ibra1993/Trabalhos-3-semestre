Projeto fruto de um trabalho propostado pelo professor de Estrutura de Dados.
Este Trabalho foi desenvolvido em equipe, eu (Ibra Có), Silvio Moreira e Rafael Soares.
Objetivo do trabalho é acessar o seguinte site: "https://www.submarinecablemap.com/" a partir dali pegar todos os landing points colocar num arquivo.txt e de lá(a partir do arquivo.txt) criar um programa em C com o tipo de dados LISTAS ENCADEADAS que recebe esses dados do arquivo e insira na lista.

 
